sh tomcat7_8081/bin/catalina.sh stop
sh tomcat7_8082/bin/catalina.sh stop
